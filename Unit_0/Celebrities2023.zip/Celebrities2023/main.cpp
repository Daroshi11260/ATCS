#include <iostream>

using namespace std;

int main() {

    cout << "GAME OVER!" <<  endl;
    return 0;
}