#include <iostream>
using namespace std;

int main() {
    cout << "Goodbye!" << endl;
    return 0;
}
